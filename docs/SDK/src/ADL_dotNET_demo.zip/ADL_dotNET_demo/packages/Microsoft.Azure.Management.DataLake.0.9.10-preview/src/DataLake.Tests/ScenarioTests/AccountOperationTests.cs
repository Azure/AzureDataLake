﻿//
// Copyright (c) Microsoft.  All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
using Microsoft.Azure;
using Microsoft.Azure.Management.DataLake;
using Microsoft.Azure.Management.DataLake.Models;
using Microsoft.Azure.Test;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Xunit;
namespace DataLake.Tests
{
    public class AccountOperationTests : TestBase, IUseFixture<CommonTestFixture>
    {   
        private CommonTestFixture commonData;
        public void SetFixture(CommonTestFixture data)
        {
            commonData = data;
        }

        //[Fact]
        //Failed to execute for Could not load file or assembly "xunit.runner.visualstudio.testadapter.XmlSerializers, Version=0.99.9.0"
        public void CreateGetUpdateDeleteTest()
        {
            TestUtilities.StartTest();
            var clientToUse = this.GetDataLakeManagementClient();

            // Create a test account
            var responseCreate =
                clientToUse.DataLakeAccount.Create(resourceGroupName: commonData.ResourceGroupName,
                    parameters: new DataLakeAccountCreateOrUpdateParameters
                    {
                        DataLakeAccount = new DataLakeAccount
                        {
                            Name = commonData.DataLakeAccountName,
                            Location = commonData.Location,
                            Tags = new Dictionary<string, string>
                            {
                                { "testkey","testvalue" }
                            }
                        }
                    });

            Assert.Equal(HttpStatusCode.OK, responseCreate.StatusCode);
            Assert.Equal(OperationStatus.Succeeded, responseCreate.Status);
            
            // get the account and ensure that all the values are properly set.
            var responseGet = clientToUse.DataLakeAccount.Get(commonData.ResourceGroupName, commonData.DataLakeAccountName);

            // validate the account creation process
            Assert.True(responseGet.DataLakeAccount.Properties.ProvisioningState == DataLakeAccountStatus.Creating || responseGet.DataLakeAccount.Properties.ProvisioningState == DataLakeAccountStatus.Succeeded);
            Assert.NotNull(responseCreate.RequestId);
            Assert.NotNull(responseGet.RequestId);
            Assert.Contains(commonData.DataLakeAccountName, responseGet.DataLakeAccount.Id);
            Assert.Contains(commonData.DataLakeAccountName, responseGet.DataLakeAccount.Properties.Endpoint);
            Assert.Equal(commonData.Location, responseGet.DataLakeAccount.Location);
            Assert.Equal(commonData.DataLakeAccountName, responseGet.DataLakeAccount.Name);
            Assert.Equal("Microsoft.DataLake/dataLakeAccounts", responseGet.DataLakeAccount.Type);
            Assert.Null(responseGet.DataLakeAccount.Properties.Error);

            // wait for provisioning state to be Succeeded
            // we will wait a maximum of 15 minutes for this to happen and then report failures
            int timeToWaitInMinutes = 15;
            int minutesWaited = 0;
            while (responseGet.DataLakeAccount.Properties.ProvisioningState != DataLakeAccountStatus.Succeeded && responseGet.DataLakeAccount.Properties.ProvisioningState != DataLakeAccountStatus.Error && minutesWaited <= timeToWaitInMinutes)
            {
                TestUtilities.Wait(60000); // Wait for one minute and then go again.
                minutesWaited++;
                responseGet = clientToUse.DataLakeAccount.Get(commonData.ResourceGroupName, commonData.DataLakeAccountName);
            }

            // Confirm that the account creation did succeed
            Assert.True(responseGet.DataLakeAccount.Properties.ProvisioningState == DataLakeAccountStatus.Succeeded);

            // Update the account and confirm the updates make it in.
            var newAccount = responseGet.DataLakeAccount;
            newAccount.Tags = new Dictionary<string, string>
            {
                {"updatedKey", "updatedValue"}
            };

            var updateResponse = clientToUse.DataLakeAccount.Update(commonData.ResourceGroupName, new DataLakeAccountCreateOrUpdateParameters
                {
                    DataLakeAccount = newAccount,
                });

            Assert.Equal(HttpStatusCode.OK, updateResponse.StatusCode);
            Assert.Equal(OperationStatus.Succeeded, updateResponse.Status);

            var updateResponseGet = clientToUse.DataLakeAccount.Get(commonData.ResourceGroupName, commonData.DataLakeAccountName);

            Assert.NotNull(updateResponse.RequestId);
            Assert.Contains(responseGet.DataLakeAccount.Id, updateResponseGet.DataLakeAccount.Id);
            Assert.Equal(responseGet.DataLakeAccount.Location, updateResponseGet.DataLakeAccount.Location);
            Assert.Equal(newAccount.Name, updateResponseGet.DataLakeAccount.Name);
            Assert.Equal(responseGet.DataLakeAccount.Type, updateResponseGet.DataLakeAccount.Type);

            // verify the new tags. NOTE: sequence equal is not ideal if we have more than 1 tag, since the ordering can change.
            Assert.True(updateResponseGet.DataLakeAccount.Tags.SequenceEqual(newAccount.Tags));

            // Create another account and ensure that list account returns both
            var accountToChange = updateResponseGet.DataLakeAccount;
            accountToChange.Name = accountToChange.Name + "secondacct";
            var parameters = new DataLakeAccountCreateOrUpdateParameters
            {
                DataLakeAccount = accountToChange
            };

            clientToUse.DataLakeAccount.Create(commonData.ResourceGroupName, parameters);

            DataLakeAccountListResponse listResponse = clientToUse.DataLakeAccount.List(commonData.ResourceGroupName, null);

            // Assert that there are at least two accounts in the list
            Assert.True(listResponse.Value.Count > 1);

            // Delete the account and confirm that it is deleted.
            AzureOperationResponse deleteResponse = clientToUse.DataLakeAccount.Delete(commonData.ResourceGroupName, newAccount.Name);

            // define the list of accepted status codes when deleting an account.
            List<HttpStatusCode> acceptedStatusCodes = new List<HttpStatusCode>
            {
                HttpStatusCode.OK,
                HttpStatusCode.Accepted,
                HttpStatusCode.NotFound,
                HttpStatusCode.NoContent
            };

            Assert.Contains<HttpStatusCode>(deleteResponse.StatusCode, acceptedStatusCodes);
            Assert.NotNull(deleteResponse.RequestId);

            // delete the account again and make sure it continues to result in a succesful code.
            deleteResponse = clientToUse.DataLakeAccount.Delete(commonData.ResourceGroupName, newAccount.Name);
            Assert.Contains<HttpStatusCode>(deleteResponse.StatusCode, acceptedStatusCodes);

            // delete the account with its old name, which should also succeed.
            deleteResponse = clientToUse.DataLakeAccount.Delete(commonData.ResourceGroupName, commonData.DataLakeAccountName);
            Assert.Contains<HttpStatusCode>(deleteResponse.StatusCode, acceptedStatusCodes);

            TestUtilities.EndTest();
        }
    }
}
